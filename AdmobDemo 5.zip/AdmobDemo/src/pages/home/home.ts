import { Component } from '@angular/core';

import { NavController, Platform} from 'ionic-angular';

declare var AdMob: any;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  private admobId: any;

  constructor(private navController: NavController, private platform: Platform) {
    this.platform = platform;

    // For Android Platform
    if (/(android)/i.test(navigator.userAgent)) {
      this.admobId = {
        banner: 'ca-app-pub-8741987551042063/7789351232', // change with your  banner admobId
        interstitial: 'ca-app-pub-8741987551042063/8663745630' // change with your interstitial admobId
      };
    }

    // For iOS Platform
    else if (/(ipod|iphone|ipad)/i.test(navigator.userAgent)) {
      this.admobId = {
        banner: 'ca-app-pub-8741987551042063/7789351232', // change with your  banner admobId
        interstitial: 'ca-app-pub-8741987551042063/8663745630' // change with your interstitial admobId
      };
    }
  }

  createBanner() {
    this.platform.ready().then(() => {
      if (AdMob) {
        AdMob.createBanner({
          adId: this.admobId.banner,
          autoShow: false
        });
      }
    });
  }

  showInterstitial() {
    this.platform.ready().then(() => {
      if (AdMob) {
        AdMob.prepareInterstitial({
          adId: this.admobId.interstitial,
          autoShow: true
        });
      }
    });
  }

  showBanner(position) {
    this.platform.ready().then(() => {
      if (AdMob) {
        var positionMap = {
          "bottom": AdMob.AD_POSITION.BOTTOM_CENTER,
          "top": AdMob.AD_POSITION.TOP_CENTER
        };
        AdMob.showBanner(positionMap[position.toLowerCase()]);
      }
    });
  }

  hideBanner(position) {
    this.platform.ready().then(() => {
      if (AdMob) {
        AdMob.hideBanner();
      }
    });
  }
}
